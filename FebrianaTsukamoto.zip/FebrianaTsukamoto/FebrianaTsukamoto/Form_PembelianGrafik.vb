﻿Public Class Form_PembelianGrafik

    Public Function BuatFuzzy() As fuzzy_set
        Dim sedikitA As Double = CDbl(Val(TextBox1.Text))
        Dim sedikitB As Double = CDbl(Val(TextBox3.Text))
        Dim pembelianSedikit As New fuzzy_grafikMenurun(sedikitA, sedikitB)

        Dim sedangA As Double = CDbl(Val(TextBox2.Text))
        Dim sedangB As Double = CDbl(Val(TextBox4.Text))
        Dim sedangC As Double = CDbl(Val(TextBox6.Text))
        Dim pembelianSedang As New fuzzy_grafikSegitiga(sedangA, sedangB, sedangC)

        Dim banyakA As Double = CDbl(Val(TextBox5.Text))
        Dim banyakB As Double = CDbl(Val(TextBox7.Text))
        Dim pembelianBanyak As New fuzzy_grafikMenanjak(banyakA, banyakB)

        Dim fuzzysetPembelian As New fuzzy_set
        fuzzysetPembelian.keanggotaan1 = pembelianSedikit
        fuzzysetPembelian.keanggotaan2 = pembelianSedang
        fuzzysetPembelian.keanggotaan3 = pembelianBanyak

        Return fuzzysetPembelian
    End Function
End Class