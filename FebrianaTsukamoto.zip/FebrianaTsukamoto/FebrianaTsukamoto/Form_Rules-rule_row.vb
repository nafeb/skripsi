﻿Public Class Form_Rules_rule_row
    Public Function getRule() As String()

    End Function

    Private Function rulestringToCode(rulestring As String) As Integer
        Select Case rulestring
            Case "Penjualan Sedikit"
                Return 0
            Case "Penjualan Sedang"
                Return 0
            Case "Penjualan Banyak"
                Return 0
        End Select
        Return 0
    End Function
End Class