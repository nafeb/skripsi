﻿Public Class Form_StokGrafik

    Public Function BuatFuzzy() As fuzzy_set
        Dim sedikitA As Double = CDbl(Val(TextBox1.Text))
        Dim sedikitB As Double = CDbl(Val(TextBox3.Text))
        Dim stokSedikit As New fuzzy_grafikMenurun(sedikitA, sedikitB)

        Dim sedangA As Double = CDbl(Val(TextBox2.Text))
        Dim sedangB As Double = CDbl(Val(TextBox4.Text))
        Dim sedangC As Double = CDbl(Val(TextBox6.Text))
        Dim stokSedang As New fuzzy_grafikSegitiga(sedangA, sedangB, sedangC)

        Dim banyakA As Double = CDbl(Val(TextBox5.Text))
        Dim banyakB As Double = CDbl(Val(TextBox7.Text))
        Dim stokBanyak As New fuzzy_grafikMenanjak(banyakA, banyakB)

        Dim fuzzysetStok As New fuzzy_set
        fuzzysetStok.keanggotaan1 = stokSedikit
        fuzzysetStok.keanggotaan2 = stokSedang
        fuzzysetStok.keanggotaan3 = stokBanyak

        Return fuzzysetStok
    End Function
End Class