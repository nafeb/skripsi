﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class FormUtama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.BtnDataPenjualan = New System.Windows.Forms.Button()
        Me.BtnFuzzyPenjualan = New System.Windows.Forms.Button()
        Me.BtnFuzzyStok = New System.Windows.Forms.Button()
        Me.BtnDataStok = New System.Windows.Forms.Button()
        Me.BtnFuzzyHarga = New System.Windows.Forms.Button()
        Me.BtnDataHarga = New System.Windows.Forms.Button()
        Me.BtnFuzzyKedaluwarsa = New System.Windows.Forms.Button()
        Me.BtnDataKedaluwarsa = New System.Windows.Forms.Button()
        Me.BtnFuzzyPembelian = New System.Windows.Forms.Button()
        Me.BtnDataPembelian = New System.Windows.Forms.Button()
        Me.TxtPenjualan = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtStok = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TxtHarga = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TxtKedaluwarsa = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TxtPembelian = New System.Windows.Forms.TextBox()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.BtnHitung = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnDataPenjualan
        '
        Me.BtnDataPenjualan.Location = New System.Drawing.Point(170, 3)
        Me.BtnDataPenjualan.Name = "BtnDataPenjualan"
        Me.BtnDataPenjualan.Size = New System.Drawing.Size(120, 49)
        Me.BtnDataPenjualan.TabIndex = 0
        Me.BtnDataPenjualan.Text = "Data Penjualan"
        Me.BtnDataPenjualan.UseVisualStyleBackColor = True
        '
        'BtnFuzzyPenjualan
        '
        Me.BtnFuzzyPenjualan.Location = New System.Drawing.Point(3, 3)
        Me.BtnFuzzyPenjualan.Name = "BtnFuzzyPenjualan"
        Me.BtnFuzzyPenjualan.Size = New System.Drawing.Size(120, 49)
        Me.BtnFuzzyPenjualan.TabIndex = 1
        Me.BtnFuzzyPenjualan.Text = "Fuzzy Set Penjualan"
        Me.BtnFuzzyPenjualan.UseVisualStyleBackColor = True
        '
        'BtnFuzzyStok
        '
        Me.BtnFuzzyStok.Location = New System.Drawing.Point(3, 3)
        Me.BtnFuzzyStok.Name = "BtnFuzzyStok"
        Me.BtnFuzzyStok.Size = New System.Drawing.Size(120, 49)
        Me.BtnFuzzyStok.TabIndex = 3
        Me.BtnFuzzyStok.Text = "Fuzzy Set Stok"
        Me.BtnFuzzyStok.UseVisualStyleBackColor = True
        '
        'BtnDataStok
        '
        Me.BtnDataStok.Location = New System.Drawing.Point(170, 3)
        Me.BtnDataStok.Name = "BtnDataStok"
        Me.BtnDataStok.Size = New System.Drawing.Size(120, 49)
        Me.BtnDataStok.TabIndex = 2
        Me.BtnDataStok.Text = "Data Stok"
        Me.BtnDataStok.UseVisualStyleBackColor = True
        '
        'BtnFuzzyHarga
        '
        Me.BtnFuzzyHarga.Location = New System.Drawing.Point(3, 3)
        Me.BtnFuzzyHarga.Name = "BtnFuzzyHarga"
        Me.BtnFuzzyHarga.Size = New System.Drawing.Size(120, 49)
        Me.BtnFuzzyHarga.TabIndex = 5
        Me.BtnFuzzyHarga.Text = "Fuzzy Set Harga"
        Me.BtnFuzzyHarga.UseVisualStyleBackColor = True
        '
        'BtnDataHarga
        '
        Me.BtnDataHarga.Location = New System.Drawing.Point(170, 3)
        Me.BtnDataHarga.Name = "BtnDataHarga"
        Me.BtnDataHarga.Size = New System.Drawing.Size(120, 49)
        Me.BtnDataHarga.TabIndex = 4
        Me.BtnDataHarga.Text = "Data Harga"
        Me.BtnDataHarga.UseVisualStyleBackColor = True
        '
        'BtnFuzzyKedaluwarsa
        '
        Me.BtnFuzzyKedaluwarsa.Location = New System.Drawing.Point(3, 3)
        Me.BtnFuzzyKedaluwarsa.Name = "BtnFuzzyKedaluwarsa"
        Me.BtnFuzzyKedaluwarsa.Size = New System.Drawing.Size(120, 49)
        Me.BtnFuzzyKedaluwarsa.TabIndex = 7
        Me.BtnFuzzyKedaluwarsa.Text = "Fuzzy Set Kedaluwarsa"
        Me.BtnFuzzyKedaluwarsa.UseVisualStyleBackColor = True
        '
        'BtnDataKedaluwarsa
        '
        Me.BtnDataKedaluwarsa.Location = New System.Drawing.Point(170, 3)
        Me.BtnDataKedaluwarsa.Name = "BtnDataKedaluwarsa"
        Me.BtnDataKedaluwarsa.Size = New System.Drawing.Size(120, 49)
        Me.BtnDataKedaluwarsa.TabIndex = 6
        Me.BtnDataKedaluwarsa.Text = "Data Kedaluwarsa"
        Me.BtnDataKedaluwarsa.UseVisualStyleBackColor = True
        '
        'BtnFuzzyPembelian
        '
        Me.BtnFuzzyPembelian.Location = New System.Drawing.Point(3, 3)
        Me.BtnFuzzyPembelian.Name = "BtnFuzzyPembelian"
        Me.BtnFuzzyPembelian.Size = New System.Drawing.Size(120, 49)
        Me.BtnFuzzyPembelian.TabIndex = 9
        Me.BtnFuzzyPembelian.Text = "Fuzzy Set Pembelian"
        Me.BtnFuzzyPembelian.UseVisualStyleBackColor = True
        '
        'BtnDataPembelian
        '
        Me.BtnDataPembelian.Location = New System.Drawing.Point(170, 3)
        Me.BtnDataPembelian.Name = "BtnDataPembelian"
        Me.BtnDataPembelian.Size = New System.Drawing.Size(120, 49)
        Me.BtnDataPembelian.TabIndex = 8
        Me.BtnDataPembelian.Text = "Data Pembelian"
        Me.BtnDataPembelian.UseVisualStyleBackColor = True
        '
        'TxtPenjualan
        '
        Me.TxtPenjualan.Location = New System.Drawing.Point(354, 32)
        Me.TxtPenjualan.Name = "TxtPenjualan"
        Me.TxtPenjualan.Size = New System.Drawing.Size(100, 20)
        Me.TxtPenjualan.TabIndex = 10
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(354, 13)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(136, 13)
        Me.Label1.TabIndex = 11
        Me.Label1.Text = "Penjualan (1 bulan terakhir)"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(354, 13)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 13)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Stok sekarang"
        '
        'TxtStok
        '
        Me.TxtStok.Location = New System.Drawing.Point(354, 32)
        Me.TxtStok.Name = "TxtStok"
        Me.TxtStok.Size = New System.Drawing.Size(100, 20)
        Me.TxtStok.TabIndex = 12
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(354, 13)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(36, 13)
        Me.Label3.TabIndex = 15
        Me.Label3.Text = "Harga"
        '
        'TxtHarga
        '
        Me.TxtHarga.Location = New System.Drawing.Point(354, 32)
        Me.TxtHarga.Name = "TxtHarga"
        Me.TxtHarga.Size = New System.Drawing.Size(100, 20)
        Me.TxtHarga.TabIndex = 14
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(357, 13)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(190, 13)
        Me.Label4.TabIndex = 17
        Me.Label4.Text = "Kedaluwarsa (produk yang akan dibeli)"
        '
        'TxtKedaluwarsa
        '
        Me.TxtKedaluwarsa.Location = New System.Drawing.Point(357, 32)
        Me.TxtKedaluwarsa.Name = "TxtKedaluwarsa"
        Me.TxtKedaluwarsa.Size = New System.Drawing.Size(100, 20)
        Me.TxtKedaluwarsa.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(354, 13)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(108, 13)
        Me.Label5.TabIndex = 19
        Me.Label5.Text = "Jumlah Pembelian"
        '
        'TxtPembelian
        '
        Me.TxtPembelian.Enabled = False
        Me.TxtPembelian.Location = New System.Drawing.Point(354, 32)
        Me.TxtPembelian.Name = "TxtPembelian"
        Me.TxtPembelian.Size = New System.Drawing.Size(100, 20)
        Me.TxtPembelian.TabIndex = 18
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.BtnFuzzyPenjualan)
        Me.Panel1.Controls.Add(Me.BtnDataPenjualan)
        Me.Panel1.Controls.Add(Me.TxtPenjualan)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(22, 30)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(549, 60)
        Me.Panel1.TabIndex = 20
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.BtnFuzzyStok)
        Me.Panel2.Controls.Add(Me.BtnDataStok)
        Me.Panel2.Controls.Add(Me.TxtStok)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Location = New System.Drawing.Point(22, 120)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(549, 60)
        Me.Panel2.TabIndex = 21
        '
        'Panel3
        '
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.BtnFuzzyKedaluwarsa)
        Me.Panel3.Controls.Add(Me.BtnDataKedaluwarsa)
        Me.Panel3.Controls.Add(Me.TxtKedaluwarsa)
        Me.Panel3.Controls.Add(Me.Label4)
        Me.Panel3.Location = New System.Drawing.Point(22, 305)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(549, 60)
        Me.Panel3.TabIndex = 22
        '
        'Panel4
        '
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.BtnFuzzyHarga)
        Me.Panel4.Controls.Add(Me.BtnDataHarga)
        Me.Panel4.Controls.Add(Me.TxtHarga)
        Me.Panel4.Controls.Add(Me.Label3)
        Me.Panel4.Location = New System.Drawing.Point(23, 209)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(549, 60)
        Me.Panel4.TabIndex = 23
        '
        'Panel5
        '
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.BtnFuzzyPembelian)
        Me.Panel5.Controls.Add(Me.BtnDataPembelian)
        Me.Panel5.Controls.Add(Me.TxtPembelian)
        Me.Panel5.Controls.Add(Me.Label5)
        Me.Panel5.Location = New System.Drawing.Point(23, 395)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(549, 60)
        Me.Panel5.TabIndex = 24
        '
        'Panel6
        '
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.BtnHitung)
        Me.Panel6.Location = New System.Drawing.Point(572, 395)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(110, 60)
        Me.Panel6.TabIndex = 25
        '
        'BtnHitung
        '
        Me.BtnHitung.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnHitung.Location = New System.Drawing.Point(15, 3)
        Me.BtnHitung.Name = "BtnHitung"
        Me.BtnHitung.Size = New System.Drawing.Size(80, 52)
        Me.BtnHitung.TabIndex = 0
        Me.BtnHitung.Text = "Hitung Prediksi Pembelian"
        Me.BtnHitung.UseVisualStyleBackColor = True
        '
        'FormUtama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(702, 487)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "FormUtama"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FormUtama"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.Panel6.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents BtnDataPenjualan As Windows.Forms.Button
    Friend WithEvents BtnFuzzyPenjualan As Windows.Forms.Button
    Friend WithEvents BtnFuzzyStok As Windows.Forms.Button
    Friend WithEvents BtnDataStok As Windows.Forms.Button
    Friend WithEvents BtnFuzzyHarga As Windows.Forms.Button
    Friend WithEvents BtnDataHarga As Windows.Forms.Button
    Friend WithEvents BtnFuzzyKedaluwarsa As Windows.Forms.Button
    Friend WithEvents BtnDataKedaluwarsa As Windows.Forms.Button
    Friend WithEvents BtnFuzzyPembelian As Windows.Forms.Button
    Friend WithEvents BtnDataPembelian As Windows.Forms.Button
    Friend WithEvents TxtPenjualan As Windows.Forms.TextBox
    Friend WithEvents Label1 As Windows.Forms.Label
    Friend WithEvents Label2 As Windows.Forms.Label
    Friend WithEvents TxtStok As Windows.Forms.TextBox
    Friend WithEvents Label3 As Windows.Forms.Label
    Friend WithEvents TxtHarga As Windows.Forms.TextBox
    Friend WithEvents Label4 As Windows.Forms.Label
    Friend WithEvents TxtKedaluwarsa As Windows.Forms.TextBox
    Friend WithEvents Label5 As Windows.Forms.Label
    Friend WithEvents TxtPembelian As Windows.Forms.TextBox
    Friend WithEvents Panel1 As Windows.Forms.Panel
    Friend WithEvents Panel2 As Windows.Forms.Panel
    Friend WithEvents Panel3 As Windows.Forms.Panel
    Friend WithEvents Panel4 As Windows.Forms.Panel
    Friend WithEvents Panel5 As Windows.Forms.Panel
    Friend WithEvents Panel6 As Windows.Forms.Panel
    Friend WithEvents BtnHitung As Windows.Forms.Button
End Class
