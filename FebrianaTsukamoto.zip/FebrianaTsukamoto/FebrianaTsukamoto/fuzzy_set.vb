﻿Public Class fuzzy_set
    Public keanggotaan1 As fuzzy_grafikMenurun
    Public keanggotaan2 As fuzzy_grafikSegitiga
    Public keanggotaan3 As fuzzy_grafikMenanjak

    Public Sub HitungSemuaKeanggotaan(ByVal x As Double)
        keanggotaan1.HitungKeanggotaan(x)
        keanggotaan2.HitungKeanggotaan(x)
        keanggotaan3.HitungKeanggotaan(x)
    End Sub
End Class
