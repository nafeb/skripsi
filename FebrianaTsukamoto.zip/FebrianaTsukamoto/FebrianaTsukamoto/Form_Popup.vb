﻿Imports System.Windows.Forms

Public Class Form_Popup
    Inherits Form

    ' Constructor
    Public Sub New()
        ' Enable KeyPreview so the form can detect key presses
        Me.KeyPreview = True
    End Sub

    ' Handle the Escape key
    Protected Overrides Sub OnKeyDown(e As KeyEventArgs)
        MyBase.OnKeyDown(e)

        If e.KeyCode = Keys.Escape Then
            ' Default action when Escape is pressed
            Me.HandleEscapeKey()
        End If
    End Sub

    ' Override the FormClosing event to prevent disposal
    Protected Overrides Sub OnFormClosing(e As FormClosingEventArgs)
        If e.CloseReason = CloseReason.UserClosing Then
            e.Cancel = True ' Cancel the close action
            Me.Hide()       ' Hide the form
        End If

        MyBase.OnFormClosing(e)
    End Sub

    ' Virtual method to handle the Escape key (can be overridden)
    Protected Overridable Sub HandleEscapeKey()
        ' Default behavior: Close the form
        Me.Hide()
    End Sub
End Class