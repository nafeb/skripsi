﻿Imports System.Collections.Generic
Imports System.Diagnostics
Imports System.Math
Public Class FormUtama

    Private Sub BtnHitung_Click(sender As Object, e As EventArgs) Handles BtnHitung.Click
        HitungFuzzy()
    End Sub

    Private Sub HitungFuzzy()
        Dim fuzzy_penjualan As fuzzy_set = formPenjualanGrafik.BuatFuzzy()
        Dim fuzzy_stok As fuzzy_set = formStokGrafik.BuatFuzzy()
        Dim fuzzy_harga As fuzzy_set = formHargaGrafik.BuatFuzzy()
        Dim fuzzy_kedaluwarsa As fuzzy_set = formKedaluwarsaGrafik.BuatFuzzy()
        Dim fuzzy_pembelian As fuzzy_set = formPembelianGrafik.BuatFuzzy()

        GetInput()
        fuzzy_penjualan.HitungSemuaKeanggotaan(xPenjualan)
        fuzzy_stok.HitungSemuaKeanggotaan(xStok)
        fuzzy_harga.HitungSemuaKeanggotaan(xHarga)
        fuzzy_kedaluwarsa.HitungSemuaKeanggotaan(xKedaluwarsa)

        Dim rulesWeight As New List(Of Double) From {
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_stok.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_stok.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_stok.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_stok.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_stok.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_stok.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_stok.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_stok.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_stok.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_harga.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_harga.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_harga.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_harga.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_harga.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_harga.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_harga.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_harga.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_harga.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan1.nilaiKeanggotaan, fuzzy_harga.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan1.nilaiKeanggotaan, fuzzy_harga.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan1.nilaiKeanggotaan, fuzzy_harga.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan2.nilaiKeanggotaan, fuzzy_harga.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan2.nilaiKeanggotaan, fuzzy_harga.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan2.nilaiKeanggotaan, fuzzy_harga.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan3.nilaiKeanggotaan, fuzzy_harga.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan3.nilaiKeanggotaan, fuzzy_harga.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan3.nilaiKeanggotaan, fuzzy_harga.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_stok.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan1.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan2.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan),
            Min(fuzzy_harga.keanggotaan3.nilaiKeanggotaan, fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan)
        }

        Dim rulesOutput As New List(Of Double) From {
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(0)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(1)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(2)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(3)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(4)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(5)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(6)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(7)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(8)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(9)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(10)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(11)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(12)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(13)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(14)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(15)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(16)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(17)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(18)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(19)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(20)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(21)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(22)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(23)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(24)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(25)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(26)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(27)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(28)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(29)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(30)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(31)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(32)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(33)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(34)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(35)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(36)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(37)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(38)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(39)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(40)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(41)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(42)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(43)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(44)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(45)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp2(rulesWeight(46)),
            fuzzy_pembelian.keanggotaan3.HitungCrisp(rulesWeight(47)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(48)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(49)),
            fuzzy_pembelian.keanggotaan2.HitungCrisp1(rulesWeight(50)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(51)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(52)),
            fuzzy_pembelian.keanggotaan1.HitungCrisp(rulesWeight(53))
        }

        Debug.WriteLine("Penjualan sedikit: " & fuzzy_penjualan.keanggotaan1.nilaiKeanggotaan)
        Debug.WriteLine("Penjualan sedang: " & fuzzy_penjualan.keanggotaan2.nilaiKeanggotaan)
        Debug.WriteLine("Penjualan banyak: " & fuzzy_penjualan.keanggotaan3.nilaiKeanggotaan)
        Debug.WriteLine("Stok sedikit: " & fuzzy_stok.keanggotaan1.nilaiKeanggotaan)
        Debug.WriteLine("Stok sedang: " & fuzzy_stok.keanggotaan2.nilaiKeanggotaan)
        Debug.WriteLine("Stok banyak: " & fuzzy_stok.keanggotaan3.nilaiKeanggotaan)
        Debug.WriteLine("Harga murah: " & fuzzy_harga.keanggotaan1.nilaiKeanggotaan)
        Debug.WriteLine("Harga sedang: " & fuzzy_harga.keanggotaan2.nilaiKeanggotaan)
        Debug.WriteLine("Harga mahal: " & fuzzy_harga.keanggotaan3.nilaiKeanggotaan)
        Debug.WriteLine("Kedaluwarsa sebentar: " & fuzzy_kedaluwarsa.keanggotaan1.nilaiKeanggotaan)
        Debug.WriteLine("Kedaluwarsa sedang: " & fuzzy_kedaluwarsa.keanggotaan2.nilaiKeanggotaan)
        Debug.WriteLine("Kedaluwarsa lama: " & fuzzy_kedaluwarsa.keanggotaan3.nilaiKeanggotaan)

        Dim sumAtas As Double = 0
        Dim sumBawah As Double = 0
        For i As Integer = 0 To 53
            Debug.WriteLine("Rules Weight " & i & " : " & rulesWeight(i))
            Debug.WriteLine("Rules Output " & i & " : " & rulesOutput(i))
            sumAtas += (rulesOutput(i) * rulesWeight(i))
            sumBawah += rulesWeight(i)
        Next

        Dim fuzzyResult As Double = sumAtas / sumBawah
        Debug.WriteLine(sumAtas)
        Debug.WriteLine(sumBawah)
        TxtPembelian.Text = fuzzyResult.ToString()
    End Sub

    Private xPenjualan As Double
    Private xStok As Double
    Private xHarga As Double
    Private xKedaluwarsa As Double
    Private Sub GetInput()
        xPenjualan = CDbl(Val(TxtPenjualan.Text))
        xStok = CDbl(Val(TxtStok.Text))
        xHarga = CDbl(Val(TxtHarga.Text))
        xKedaluwarsa = CDbl(Val(TxtKedaluwarsa.Text))
    End Sub

    Private formRules As New FormRules
    Private formPenjualanGrafik As New Form_PenjualanGrafik
    Private formPenjualanData As New Form_PenjualanData
    Private formStokGrafik As New Form_StokGrafik
    Private formStokData As New Form_StokData
    Private formHargaGrafik As New Form_HargaGrafik
    Private formHargaData As New Form_HargaData
    Private formKedaluwarsaGrafik As New Form_KedaluwarsaGrafik
    Private formKedaluwarsaData As New Form_KedaluwarsaData
    Private formPembelianGrafik As New Form_PembelianGrafik
    Private formPembelianData As New Form_PembelianData
    Private Sub BtnRules_Click(sender As Object, e As EventArgs)
        formRules.ShowDialog()
    End Sub
    Private Sub BtnFuzzyPenjualan_Click(sender As Object, e As EventArgs) Handles BtnFuzzyPenjualan.Click
        formPenjualanGrafik.ShowDialog()
    End Sub
    Private Sub BtnDataPenjualan_Click(sender As Object, e As EventArgs) Handles BtnDataPenjualan.Click
        formPenjualanData.ShowDialog()
    End Sub
    Private Sub BtnFuzzyStok_Click(sender As Object, e As EventArgs) Handles BtnFuzzyStok.Click
        formStokGrafik.ShowDialog()
    End Sub
    Private Sub BtnDataStok_Click(sender As Object, e As EventArgs) Handles BtnDataStok.Click
        formStokData.ShowDialog()
    End Sub
    Private Sub BtnFuzzyHarga_Click(sender As Object, e As EventArgs) Handles BtnFuzzyHarga.Click
        formHargaGrafik.ShowDialog()
    End Sub
    Private Sub BtnDataHarga_Click(sender As Object, e As EventArgs) Handles BtnDataHarga.Click
        formHargaData.ShowDialog()
    End Sub
    Private Sub BtnFuzzyKedaluwarsa_Click(sender As Object, e As EventArgs) Handles BtnFuzzyKedaluwarsa.Click
        formKedaluwarsaGrafik.ShowDialog()
    End Sub
    Private Sub BtnDataKedaluwarsa_Click(sender As Object, e As EventArgs) Handles BtnDataKedaluwarsa.Click
        formKedaluwarsaData.ShowDialog()
    End Sub
    Private Sub BtnFuzzyPembelian_Click(sender As Object, e As EventArgs) Handles BtnFuzzyPembelian.Click
        formPembelianGrafik.ShowDialog()
    End Sub
    Private Sub BtnDataPembelian_Click(sender As Object, e As EventArgs) Handles BtnDataPembelian.Click
        formPembelianData.ShowDialog()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs)
        GetInput()
    End Sub
End Class