﻿Public Class Form_HargaGrafik


    Public Function BuatFuzzy() As fuzzy_set
        Dim murahA As Double = CDbl(Val(TextBox1.Text))
        Dim murahB As Double = CDbl(Val(TextBox3.Text))
        Dim hargaMurah As New fuzzy_grafikMenurun(murahA, murahB)

        Dim sedangA As Double = CDbl(Val(TextBox2.Text))
        Dim sedangB As Double = CDbl(Val(TextBox4.Text))
        Dim sedangC As Double = CDbl(Val(TextBox6.Text))
        Dim hargaSedang As New fuzzy_grafikSegitiga(sedangA, sedangB, sedangC)

        Dim mahalA As Double = CDbl(Val(TextBox5.Text))
        Dim mahalB As Double = CDbl(Val(TextBox7.Text))
        Dim hargaMahal As New fuzzy_grafikMenanjak(mahalA, mahalB)

        Dim fuzzysetHarga As New fuzzy_set
        fuzzysetHarga.keanggotaan1 = hargaMurah
        fuzzysetHarga.keanggotaan2 = hargaSedang
        fuzzysetHarga.keanggotaan3 = hargaMahal

        Return fuzzysetHarga
    End Function
End Class