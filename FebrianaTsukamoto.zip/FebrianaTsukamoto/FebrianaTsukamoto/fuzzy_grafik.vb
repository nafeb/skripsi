﻿Public Class fuzzy_grafik
    Public a As Double
    Public b As Double
    Public c As Double

    Public nilaiKeanggotaan As Double
    Public nilaiCrisp As Double
    Public nilaiCrisp2 As Double
End Class
