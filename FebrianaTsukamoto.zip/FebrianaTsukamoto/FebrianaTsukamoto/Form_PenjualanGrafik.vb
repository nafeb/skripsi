﻿Public Class Form_PenjualanGrafik

    Public Function BuatFuzzy() As fuzzy_set
        Dim sedikitA As Double = CDbl(Val(Textbox1.Text))
        Dim sedikitB As Double = CDbl(Val(TextBox3.Text))
        Dim penjualanSedikit As New fuzzy_grafikMenurun(sedikitA, sedikitB)

        Dim sedangA As Double = CDbl(Val(TextBox2.Text))
        Dim sedangB As Double = CDbl(Val(TextBox4.Text))
        Dim sedangC As Double = CDbl(Val(TextBox6.Text))
        Dim penjualanSedang As New fuzzy_grafikSegitiga(sedangA, sedangB, sedangC)

        Dim banyakA As Double = CDbl(Val(TextBox5.Text))
        Dim banyakB As Double = CDbl(Val(TextBox7.Text))
        Dim penjualanBanyak As New fuzzy_grafikMenanjak(banyakA, banyakB)

        Dim fuzzysetPenjualan As New fuzzy_set
        fuzzysetPenjualan.keanggotaan1 = penjualanSedikit
        fuzzysetPenjualan.keanggotaan2 = penjualanSedang
        fuzzysetPenjualan.keanggotaan3 = penjualanBanyak

        Return fuzzysetPenjualan
    End Function


End Class