﻿Public Class fuzzy_grafikSegitiga
    Inherits fuzzy_grafik

    Public Sub New(ByVal a As Double, ByVal b As Double, ByVal c As Double)
        Me.a = a
        Me.b = b
        Me.c = c
    End Sub

    Public Function HitungKeanggotaan(ByVal x As Double) As Double
        Select Case True
            Case x <= a
                nilaiKeanggotaan = 0
                Return 0
            Case x >= c
                nilaiKeanggotaan = 0
                Return 0
            Case x = b
                nilaiKeanggotaan = 1
                Return 1
            Case x > a And x < b
                nilaiKeanggotaan = (x - a) / (b - a)
                Return (x - a) / (b - a)
            Case x > b And x < c
                nilaiKeanggotaan = (c - x) / (c - b)
                Return (c - x) / (c - b)
        End Select

        Return 0
    End Function

    Public Function HitungKeanggotaan(ByVal x As Double, ByVal a As Double, ByVal b As Double) As Double
        Select Case x
            Case x <= a
                nilaiKeanggotaan = 0
                Return 0
            Case x >= c
                nilaiKeanggotaan = 0
                Return 0
            Case x = b
                nilaiKeanggotaan = 1
                Return 1
            Case x > a And x < b
                nilaiKeanggotaan = (x - a) / (b - a)
                Return (x - a) / (b - a)
            Case x > b And x < c
                nilaiKeanggotaan = (c - x) / (c - b)
                Return (c - x) / (c - b)
        End Select

        Return 0
    End Function

    Public Function HitungCrisp1(ByVal y As Double) As Double
        Dim crisp As Double
        crisp = y * (b - a) + a

        Return crisp
    End Function

    Public Function HitungCrisp2(ByVal y As Double) As Double
        Dim crisp As Double
        crisp = -(y * (c - b) - c)

        Return crisp
    End Function
End Class
