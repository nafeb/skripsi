﻿Public Class fuzzy_collection
    Public fuzzy_penjualan As fuzzy_set
    Public fuzzy_stok As fuzzy_set
    Public fuzzy_harga As fuzzy_set
    Public fuzzy_kedaluwarsa As fuzzy_set
    Public fuzzy_pembelian As fuzzy_set
End Class
