﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FormRules
    Inherits Form_Popup

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.panelRow = New System.Windows.Forms.Panel()
        Me.PanelBtn = New System.Windows.Forms.Panel()
        Me.BtnTambahrow = New System.Windows.Forms.Button()
        Me.Form_Rules_rule_row1 = New FebrianaTsukamoto.Form_Rules_rule_row()
        Me.panelRow.SuspendLayout()
        Me.PanelBtn.SuspendLayout()
        Me.SuspendLayout()
        '
        'panelRow
        '
        Me.panelRow.AutoSize = True
        Me.panelRow.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.panelRow.Controls.Add(Me.Form_Rules_rule_row1)
        Me.panelRow.Controls.Add(Me.PanelBtn)
        Me.panelRow.Location = New System.Drawing.Point(0, 0)
        Me.panelRow.Name = "panelRow"
        Me.panelRow.Size = New System.Drawing.Size(834, 79)
        Me.panelRow.TabIndex = 0
        '
        'PanelBtn
        '
        Me.PanelBtn.AutoSize = True
        Me.PanelBtn.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.PanelBtn.Controls.Add(Me.BtnTambahrow)
        Me.PanelBtn.Location = New System.Drawing.Point(3, 50)
        Me.PanelBtn.Name = "PanelBtn"
        Me.PanelBtn.Size = New System.Drawing.Size(801, 26)
        Me.PanelBtn.TabIndex = 1
        '
        'BtnTambahrow
        '
        Me.BtnTambahrow.Location = New System.Drawing.Point(0, 0)
        Me.BtnTambahrow.Name = "BtnTambahrow"
        Me.BtnTambahrow.Size = New System.Drawing.Size(798, 23)
        Me.BtnTambahrow.TabIndex = 0
        Me.BtnTambahrow.Text = "Tambah Rule"
        Me.BtnTambahrow.UseVisualStyleBackColor = True
        '
        'Form_Rules_rule_row1
        '
        Me.Form_Rules_rule_row1.AutoSize = True
        Me.Form_Rules_rule_row1.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.Form_Rules_rule_row1.Location = New System.Drawing.Point(0, 0)
        Me.Form_Rules_rule_row1.Margin = New System.Windows.Forms.Padding(6)
        Me.Form_Rules_rule_row1.Name = "Form_Rules_rule_row1"
        Me.Form_Rules_rule_row1.Size = New System.Drawing.Size(828, 41)
        Me.Form_Rules_rule_row1.TabIndex = 2
        '
        'FormRules
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.ClientSize = New System.Drawing.Size(840, 93)
        Me.Controls.Add(Me.panelRow)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow
        Me.Name = "FormRules"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "FormRules"
        Me.panelRow.ResumeLayout(False)
        Me.panelRow.PerformLayout()
        Me.PanelBtn.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents panelRow As Windows.Forms.Panel
    Friend WithEvents PanelBtn As Windows.Forms.Panel
    Friend WithEvents BtnTambahrow As Windows.Forms.Button
    Friend WithEvents Form_Rules_rule_row1 As Form_Rules_rule_row
End Class
