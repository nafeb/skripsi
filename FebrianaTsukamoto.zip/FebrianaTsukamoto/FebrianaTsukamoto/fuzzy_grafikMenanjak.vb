﻿Public Class fuzzy_grafikMenanjak
    Inherits fuzzy_grafik

    Public Sub New(ByVal a As Double, ByVal b As Double)
        Me.a = a
        Me.b = b
    End Sub

    Public Function HitungKeanggotaan(ByVal x As Double) As Double
        Select Case True
            Case x <= a
                nilaiKeanggotaan = 0
                Return 0
            Case x >= b
                nilaiKeanggotaan = 1
                Return 1
            Case x > a And x < b
                nilaiKeanggotaan = (x - a) / (b - a)
                Return (x - a) / (b - a)
        End Select

        Return 0
    End Function

    Public Function HitungKeanggotaan(ByVal x As Double, ByVal a As Double, ByVal b As Double) As Double
        Select Case x
            Case x <= a
                nilaiKeanggotaan = 0
                Return 0
            Case x >= b
                nilaiKeanggotaan = 1
                Return 1
            Case x > a And x < b
                nilaiKeanggotaan = (x - a) / (b - a)
                Return (x - a) / (b - a)
        End Select

        Return 0
    End Function

    Public Function HitungCrisp(ByVal y As Double) As Double
        Dim crisp As Double
        crisp = y * (b - a) + a

        Return crisp
    End Function
End Class
