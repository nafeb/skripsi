﻿Imports System.Collections.Generic
Imports System.Data

Public Class Form_PenjualanData
    Private dbhelper As DBHelper

    Private Sub FormPermintaan_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dbhelper = New DBHelper()
        show_data()
    End Sub

    Private Sub BtnSimpan_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim nama As String
        nama = txtNama.Text
        Dim periode As String
        periode = txtTanggal.Text
        Dim penjualan As String
        penjualan = txtPenjualan.Text

        If (QueryDataExists(nama, periode)) Then
            MsgBox("Data sudah ada", , "Tambah Data")
            Exit Sub
        End If

        If Not (String.IsNullOrWhiteSpace(nama) Or String.IsNullOrWhiteSpace(periode)) Then
            Dim queryStr As String = "INSERT INTO TbPenjualan (namaObat, tanggalPenjualan, JumlahPenjualan) VALUES (@nama, @tanggal, @penjualan)"
            Dim params As New Dictionary(Of String, Object) From {
                {"@nama", nama},
                {"@tanggal", periode},
                {"@penjualan", penjualan}
                }
            dbhelper.ExecuteNonQuery(queryStr, params)
        Else
            MsgBox("Nama atau Periode kosong")
        End If
        show_data()
    End Sub

    Private Function QueryDataExists(ByVal nama As String, ByVal periode As String) As Boolean
        Dim queryStr As String = "SELECT 1 FROM TbPenjualan WHERE namaObat=@nama AND tanggalPenjualan=@tanggal"
        Dim params As New Dictionary(Of String, Object) From {
                {"@nama", nama},
                {"@tanggal", periode}
                }
        Dim dt As New DataTable
        dt = dbhelper.ExecuteReaderQuery(queryStr, params)
        If (dt.Rows.Count > 0) Then
            Return True ' Data ada
        Else
            Return False ' Data tidak ada
        End If
    End Function

    Private Sub show_data()
        Dim queryStr As String = "SELECT * FROM [TbPenjualan] WHERE namaObat = @namaObat"
        Dim namaObat As String = txtNama.Text
        Dim params As New Dictionary(Of String, Object) From {
            {"@namaObat", namaObat}}

        Dim dt As New DataTable
        dt = dbhelper.ExecuteReaderQuery(queryStr, params)

        DataGridView1.DataSource = dt
        DataGridView1.Refresh()
    End Sub

    Private Sub txtNama_TextChanged(sender As Object, e As EventArgs) Handles txtNama.TextChanged
        show_data()
    End Sub
End Class