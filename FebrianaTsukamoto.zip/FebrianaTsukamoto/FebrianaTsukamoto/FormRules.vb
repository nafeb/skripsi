﻿Public Class FormRules
    Private Sub BtnTambahrow_Click(sender As Object, e As EventArgs) Handles BtnTambahrow.Click
        TambahRow()
    End Sub

    Public Sub HitungRules(ByRef fuzzyCollection As fuzzy_collection)
        Dim rule
    End Sub

    Private Sub TambahRow()
        Dim newRow As New Form_Rules_rule_row
        newRow.Dock = Windows.Forms.DockStyle.Top
        newRow.BringToFront()

        panelRow.Controls.Add(newRow)

        RelokasiPanelUtama()
    End Sub

    Private Sub RelokasiPanelUtama()
        Dim jumlahRow As Integer = panelRow.Controls.Count
        Dim tinggiRow As Integer = panelRow.Controls.Item(0).Size.Height

        PanelBtn.Location = New Drawing.Point(0, jumlahRow * tinggiRow)
    End Sub


End Class