﻿Public Class Form_KedaluwarsaGrafik

    Public Function BuatFuzzy() As fuzzy_set
        Dim sebentarA As Double = CDbl(Val(TextBox1.Text))
        Dim sebentarB As Double = CDbl(Val(TextBox3.Text))
        Dim kedaluwarsaSebentar As New fuzzy_grafikMenurun(sebentarA, sebentarB)

        Dim sedangA As Double = CDbl(Val(TextBox2.Text))
        Dim sedangB As Double = CDbl(Val(TextBox4.Text))
        Dim sedangC As Double = CDbl(Val(TextBox6.Text))
        Dim kedaluwarsaSedang As New fuzzy_grafikSegitiga(sedangA, sedangB, sedangC)

        Dim lamaA As Double = CDbl(Val(TextBox5.Text))
        Dim lamaB As Double = CDbl(Val(TextBox7.Text))
        Dim kedaluwarsaLama As New fuzzy_grafikMenanjak(lamaA, lamaB)

        Dim fuzzysetKedaluwarsa As New fuzzy_set
        fuzzysetKedaluwarsa.keanggotaan1 = kedaluwarsaSebentar
        fuzzysetKedaluwarsa.keanggotaan2 = kedaluwarsaSedang
        fuzzysetKedaluwarsa.keanggotaan3 = kedaluwarsaLama

        Return fuzzysetKedaluwarsa
    End Function
End Class